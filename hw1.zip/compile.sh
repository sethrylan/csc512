make clean all
